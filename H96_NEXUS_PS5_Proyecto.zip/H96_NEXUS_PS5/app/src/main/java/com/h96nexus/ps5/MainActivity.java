package com.h96nexus.ps5;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.text.*;

public class MainActivity extends Activity {
    private final int WHITE = Color.WHITE;
    private final int CYAN = Color.rgb(83, 190, 255);
    private final ArrayList<ResolveInfo> apps = new ArrayList<>();
    private LinearLayout root, rail;
    private TextView title, subtitle, clock, hint;
    private ImageView heroIcon;
    private int selected = 0;
    private PackageManager pm;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        pm = getPackageManager();
        loadApps();
        makeScreen();
        render();
    }

    private GradientDrawable gradient(int[] colors, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(3, stroke);
        return d;
    }
    private TextView label(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }
    private void loadApps() {
        Intent q = new Intent(Intent.ACTION_MAIN, null);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
        Collections.sort(list, (a,b) -> a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
        for (ResolveInfo r : list) {
            if (!r.activityInfo.packageName.equals(getPackageName())) apps.add(r);
        }
    }

    private void makeScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(46, 25, 46, 22);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(7,18,48), Color.rgb(9,28,70), Color.rgb(3,8,24)}));
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = label("H96  NEXUS", 25, WHITE, true);
        logo.setLetterSpacing(0.15f);
        top.addView(logo, new LinearLayout.LayoutParams(0, 48, 1));
        clock = label("", 17, 0xFFD9E9FF, false);
        clock.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        top.addView(clock, new LinearLayout.LayoutParams(-2, 48));
        root.addView(top);
        tickClock();

        LinearLayout center = new LinearLayout(this);
        center.setGravity(Gravity.CENTER);
        center.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 0, 1);
        cp.topMargin = 8;
        root.addView(center, cp);

        ImageView leftGlow = new ImageView(this);
        leftGlow.setImageDrawable(null);
        heroIcon = new ImageView(this);
        heroIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout heroFrame = new FrameLayout(this);
        heroFrame.setBackground(gradient(new int[]{0x553D85D8, 0x222A4B88}, 38, 0xAA67BFFF));
        heroFrame.setElevation(20);
        heroFrame.addView(heroIcon, new FrameLayout.LayoutParams(190, 190, Gravity.CENTER));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(230, 230);
        hp.leftMargin = 28; hp.rightMargin = 28;
        center.addView(heroFrame, hp);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL);
        title = label("Selecciona una aplicación", 29, WHITE, true);
        subtitle = label("Presiona OK para abrir", 17, 0xFFB9D4F4, false);
        hint = label("◀   ▶   MOVER     •     OK   ABRIR", 13, CYAN, true);
        info.addView(title);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 10;
        info.addView(subtitle, sp);
        LinearLayout.LayoutParams h = new LinearLayout.LayoutParams(-1, -2);
        h.topMargin = 24;
        info.addView(hint, h);
        center.addView(info, new LinearLayout.LayoutParams(0, -1, 1));

        TextView section = label("TUS APLICACIONES", 13, 0xFF9DC9F4, true);
        section.setLetterSpacing(0.18f);
        root.addView(section);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setFillViewport(false);
        rail = new LinearLayout(this);
        rail.setGravity(Gravity.CENTER_VERTICAL);
        rail.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(rail);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, 120);
        rp.topMargin = 8;
        root.addView(hsv, rp);
    }

    private void tickClock() {
        clock.setText(new SimpleDateFormat("EEE, d MMM   HH:mm", Locale.getDefault()).format(new Date()));
        new Handler().postDelayed(() -> tickClock(), 30000);
    }

    private void render() {
        rail.removeAllViews();
        if (apps.size() == 0) {
            title.setText("No hay aplicaciones");
            subtitle.setText("No se encontraron apps instaladas.");
            return;
        }
        if (selected < 0) selected = apps.size()-1;
        if (selected >= apps.size()) selected = 0;
        ResolveInfo chosen = apps.get(selected);
        title.setText(chosen.loadLabel(pm).toString());
        subtitle.setText("Aplicación seleccionada  •  " + (selected+1) + " de " + apps.size());
        try { heroIcon.setImageDrawable(chosen.loadIcon(pm)); } catch(Exception e) {}
        heroIcon.setContentDescription(chosen.loadLabel(pm).toString());

        int start = Math.max(0, selected-3);
        int end = Math.min(apps.size(), selected+4);
        for (int i=start; i<end; i++) {
            final int index = i;
            boolean active = i == selected;
            LinearLayout item = new LinearLayout(this);
            item.setGravity(Gravity.CENTER);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(8, 5, 8, 5);
            item.setBackground(gradient(
                active ? new int[]{0xCC245A9A,0xAA16396C} : new int[]{0x442D4B72,0x33203A5C},
                20, active ? CYAN : 0));
            ImageView icon = new ImageView(this);
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            try { icon.setImageDrawable(apps.get(i).loadIcon(pm)); } catch(Exception e) {}
            item.addView(icon, new LinearLayout.LayoutParams(active ? 68 : 54, active ? 68 : 54));
            TextView nm = label(apps.get(i).loadLabel(pm).toString(), 11, WHITE, active);
            nm.setGravity(Gravity.CENTER);
            nm.setMaxLines(1);
            nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
            item.addView(nm, new LinearLayout.LayoutParams(82, 24));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(active ? 112 : 94, 106);
            p.setMargins(5, 3, 5, 3);
            rail.addView(item, p);
            item.setOnClickListener(v -> { selected = index; render(); });
        }
    }

    private void launchSelected() {
        if (apps.isEmpty()) return;
        ResolveInfo r = apps.get(selected);
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setClassName(r.activityInfo.packageName, r.activityInfo.name);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch(Exception e) {
            Toast.makeText(this, "No se pudo abrir esta aplicación", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public boolean onKeyDown(int key, KeyEvent event) {
        if (apps.size() > 0) {
            if (key == KeyEvent.KEYCODE_DPAD_RIGHT) { selected++; render(); return true; }
            if (key == KeyEvent.KEYCODE_DPAD_LEFT) { selected--; render(); return true; }
            if (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER) { launchSelected(); return true; }
            if (key == KeyEvent.KEYCODE_BACK) return true;
        }
        return super.onKeyDown(key, event);
    }
}
