H96 NEXUS PS5 - Proyecto Android

Interfaz horizontal estilo consola:
- Aplicación seleccionada grande en el centro
- Carrusel de aplicaciones a los lados
- Iconos reales de aplicaciones instaladas
- Fondo azul oscuro inspirado en PS5
- Control remoto: izquierda/derecha para seleccionar, OK para abrir

Proyecto para compilar con GitHub Actions.
APK: app/build/outputs/apk/debug/app-debug.apk
